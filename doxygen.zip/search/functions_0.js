var searchData=
[
  ['avg_5ffree_0',['avg_free',['../_m_m_a_8c.html#af076506dc582417d771af51aeec179e0',1,'avg_free(uint8_t avgID):&#160;MMA.c'],['../_m_m_a_8h.html#af076506dc582417d771af51aeec179e0',1,'avg_free(uint8_t avgID):&#160;MMA.c']]],
  ['avg_5fgetaverage_1',['avg_getAverage',['../_m_m_a_8c.html#a5439245ee3581fcbc14ac1c0ca9021bf',1,'avg_getAverage(uint8_t avgID, int16_t *average):&#160;MMA.c'],['../_m_m_a_8h.html#a5439245ee3581fcbc14ac1c0ca9021bf',1,'avg_getAverage(uint8_t avgID, int16_t *average):&#160;MMA.c']]],
  ['avg_5fmovetheaverage_2',['avg_moveTheAverage',['../_m_m_a_8c.html#a0a0a4d96c1e27c523297a2474ca871dd',1,'avg_moveTheAverage(uint8_t avgID, int16_t newValue):&#160;MMA.c'],['../_m_m_a_8h.html#a0a0a4d96c1e27c523297a2474ca871dd',1,'avg_moveTheAverage(uint8_t avgID, int16_t newValue):&#160;MMA.c']]],
  ['avg_5fregister_3',['avg_register',['../_m_m_a_8c.html#a3007dccf9e250a4dc883e8da7a52b517',1,'avg_register(uint8_t *avgID):&#160;MMA.c'],['../_m_m_a_8h.html#a3007dccf9e250a4dc883e8da7a52b517',1,'avg_register(uint8_t *avgID):&#160;MMA.c']]],
  ['avg_5freset_4',['avg_reset',['../_m_m_a_8c.html#af7ae6caddf4eaae34c83a3a613d07262',1,'avg_reset(uint8_t avgID):&#160;MMA.c'],['../_m_m_a_8h.html#af7ae6caddf4eaae34c83a3a613d07262',1,'avg_reset(uint8_t avgID):&#160;MMA.c']]]
];
