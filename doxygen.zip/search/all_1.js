var searchData=
[
  ['mma_2ec_0',['MMA.c',['../_m_m_a_8c.html',1,'']]],
  ['mma_2eh_1',['MMA.h',['../_m_m_a_8h.html',1,'']]],
  ['modified_20moving_20average_2',['Modified Moving Average',['../index.html',1,'']]],
  ['movingaverage_3',['MovingAverage',['../struct_moving_average.html',1,'']]]
];
