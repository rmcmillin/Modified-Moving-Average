var searchData=
[
  ['modified_20moving_20average_0',['Modified Moving Average',['../index.html',1,'']]]
];
