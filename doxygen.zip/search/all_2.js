var searchData=
[
  ['numberofsamples_0',['numberOfSamples',['../struct_moving_average.html#a4cae0df902435bce1ed30493c08f4874',1,'MovingAverage']]]
];
