var searchData=
[
  ['state_0',['state',['../struct_moving_average.html#a66338d85121287f12670ee16bee63aae',1,'MovingAverage']]],
  ['sum_1',['sum',['../struct_moving_average.html#a607f39712288bbe0d8f28904df4a92bd',1,'MovingAverage']]]
];
