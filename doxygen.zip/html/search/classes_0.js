var searchData=
[
  ['movingaverage_0',['MovingAverage',['../struct_moving_average.html',1,'']]]
];
