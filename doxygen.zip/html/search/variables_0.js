var searchData=
[
  ['average_0',['average',['../struct_moving_average.html#a77699ad054dddaed3e88cb9da2b7715c',1,'MovingAverage']]]
];
