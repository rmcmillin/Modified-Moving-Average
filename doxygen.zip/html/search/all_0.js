var searchData=
[
  ['average_0',['average',['../struct_moving_average.html#a77699ad054dddaed3e88cb9da2b7715c',1,'MovingAverage']]],
  ['avg_5ffree_1',['avg_free',['../_m_m_a_8c.html#a740a8d446e465c2fe3d3ec64c5de8717',1,'avg_free(int8_t avgID):&#160;MMA.c'],['../_m_m_a_8h.html#a740a8d446e465c2fe3d3ec64c5de8717',1,'avg_free(int8_t avgID):&#160;MMA.c']]],
  ['avg_5fgetaverage_2',['avg_getAverage',['../_m_m_a_8c.html#ae5d57cbcb9c020a1bddef910985bee3c',1,'avg_getAverage(int8_t avgID, uint16_t *average):&#160;MMA.c'],['../_m_m_a_8h.html#ae5d57cbcb9c020a1bddef910985bee3c',1,'avg_getAverage(int8_t avgID, uint16_t *average):&#160;MMA.c']]],
  ['avg_5fmovetheaverage_3',['avg_moveTheAverage',['../_m_m_a_8c.html#ab5c1cd635c4c670e6e5aa941ea08271c',1,'avg_moveTheAverage(int8_t avgID, uint16_t newValue):&#160;MMA.c'],['../_m_m_a_8h.html#ab5c1cd635c4c670e6e5aa941ea08271c',1,'avg_moveTheAverage(int8_t avgID, uint16_t newValue):&#160;MMA.c']]],
  ['avg_5fregister_4',['avg_register',['../_m_m_a_8c.html#a3007dccf9e250a4dc883e8da7a52b517',1,'avg_register(uint8_t *avgID):&#160;MMA.c'],['../_m_m_a_8h.html#a3007dccf9e250a4dc883e8da7a52b517',1,'avg_register(uint8_t *avgID):&#160;MMA.c']]],
  ['avg_5freset_5',['avg_reset',['../_m_m_a_8c.html#a000347411280f2b596e71f4f7d0cc5ba',1,'avg_reset(int8_t avgID):&#160;MMA.c'],['../_m_m_a_8h.html#a000347411280f2b596e71f4f7d0cc5ba',1,'avg_reset(int8_t avgID):&#160;MMA.c']]]
];
